Rusted Warfare 1.15 中文 Mod 参考资料包

先读：Rusted_Warfare_1.15_Mod_中文注释手册.txt
快速查键：字段速查索引.txt

资料范围：
984 个单位/Mod 配置项；121 组逻辑注册、143 个名称（含别名）；
19 个可修改单位属性；88 个地图解析属性；
单位生成、射弹生成、资源价格、图像堆叠、动画关键帧语法；
旧式前缀、预处理、内存、事件、内置单位/声音/特效名称。

reference/：UTF-8 JSON，可用编辑器直接搜索。
unit_fields.json —— 每项的类型、中文说明、缺省处理和来源。
logic_functions.json —— 函数/属性/单位引用，参数、别名及内部保留项。
map_properties.json —— 地图属性及适用对象。
mutable_stats.json —— setUnitStats 支持的字段。
mini_languages.json —— 各专用小语法的参数。
dynamic_key_patterns.json —— 动态键和旧式兼容形式。
builtin_names.json —— 内置名称与声明位置。
package_manifest.json —— 输入包指纹和目录统计。
asset_field_coverage.json / map_asset_coverage.json —— 包内键覆盖分类。
verification_report.json —— 本次具体检查与检查边界。
analysis_summary.json —— 目录计数。

tools/search_reference.py：只读检索，可在本资料包目录执行：
python tools/search_reference.py energy
python tools/search_reference.py 炮塔
不需要安装第三方 Python 库；该脚本不是游戏加载器。

examples/Annotated_Scout：原创中文注释 Mod 源文件。
examples/Annotated_Scout.rwmod：同一示例打包后的 ZIP 容器。
examples/map_trigger_fragment.xml：需合入完整地图的对象组片段。
examples/resource_memory_fragment.ini.txt：需合入完整单位的资源/内存片段。

验证状态：实际下载并检查了指定压缩包，进行了代码/资源静态分析；
没有启动游戏或进行联机测试。不要把“有解析/实现证据”理解为所有
参数组合都实机通过。主手册区分已观察资产、代码证据与原创示例。
资料包不包含完整反编译游戏源码、原游戏二进制或游戏美术资源。

输入下载地址：
https://download.noaushio.uk/Rusted%20Warfare_1.15.zip
SHA-256：
3f2da87c881ea0dd62d536066e62003fa14d434d265f47c6ba6d80ff5bb83d9e

复核方法：
对这个 classes.dex 使用 JADX 1.5.3 的命令行入口反编译；手册中的
Java 路径与行号对应此次输出，并非开发者原始源码。关键模块是
com/corrodinggames/rts/game/units/custom（单位与动作）、
其 logicBooleans 子目录（表达式与内存）、
gameFramework/utility/ae.java（INI 类型读取）、
gameFramework/n（任务触发器）、game/b（地图/地块）。
完整包 CRC、名称 DEX 字符串核对、资产覆盖分类、样例静态类型与
交叉引用检查的结果已记录在 verification_report.json。
