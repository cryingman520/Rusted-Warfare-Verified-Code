#!/usr/bin/env python3
"""只读检索本资料包的 JSON 索引；不是游戏解析器。需要 Python 3。"""
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[1]
query=' '.join(sys.argv[1:]).strip().casefold()
if not query:
 print('用法：python tools/search_reference.py 查询词\n示例：python tools/search_reference.py energy')
 raise SystemExit(0)
count=0
for filename in ['unit_fields.json','logic_functions.json','map_properties.json','mutable_stats.json']:
 rows=json.loads((ROOT/'reference'/filename).read_text(encoding='utf-8'))
 for row in rows:
  if query not in json.dumps(row,ensure_ascii=False).casefold():continue
  name=', '.join(row['names']) if 'names' in row else row['key']
  scope=row.get('section',row.get('scope',filename))
  print(f'[{scope}] {name}\n  {row["description_zh"]}')
  if 'type' in row:print('  类型：'+row['type'])
  if 'note_zh' in row and row['note_zh']:print('  注意：'+row['note_zh'])
  if 'allowed_values' in row:print('  可选值：'+', '.join(row['allowed_values']))
  count+=1
print(f'\n匹配 {count} 项。结果以当前资料包为限，不能代替游戏加载和实机测试。')
